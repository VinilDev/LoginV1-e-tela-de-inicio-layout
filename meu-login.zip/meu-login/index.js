const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const session = require('express-session');
const app = express();

// Configura o EJS
app.set('view engine', 'ejs');

// Middlewares para capturar dados do form
app.use(express.urlencoded({ extended: true }));

// Configura sessão
app.use(session({
  secret: 'sua_chave_secreta_aqui',
  resave: false,
  saveUninitialized: false
}));

// Conexão MongoDB
mongoose.connect('mongodb+srv://ViniciusSilva:jGXBnmGxYGLSH1BP@fusion.qx2b92k.mongodb.net/loginApp?retryWrites=true&w=majority&appName=Fusion', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log('MongoDB conectado'))
  .catch(err => console.log(err));

// Modelo do usuário
const UserSchema = new mongoose.Schema({
  username: String,
  email: String,
  password: String
});
const User = mongoose.model('User', UserSchema);

// Rotas

// Tela inicial (só acessível se logado)
app.get('/home', (req, res) => {
  if (!req.session.userId) {
    return res.redirect('/login');
  }
  res.render('home', { username: req.session.username });
});

// Página de login
app.get('/login', (req, res) => {
  res.render('login');
});

// Página de registro
app.get('/register', (req, res) => {
  res.render('register');
});

// Processa registro
app.post('/register', async (req, res) => {
  const { username, email, password } = req.body;

  const userExists = await User.findOne({ email });
  if (userExists) {
    return res.send('Usuário já registrado com esse email.');
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  const user = new User({
    username,
    email,
    password: hashedPassword
  });

  await user.save();
  res.redirect('/login');
});

// Processa login
app.post('/login', async (req, res) => {
  const { email, password } = req.body;

  const user = await User.findOne({ email });
  if (!user) {
    return res.send('Usuário não encontrado.');
  }

  const passwordMatch = await bcrypt.compare(password, user.password);
  if (!passwordMatch) {
    return res.send('Senha incorreta.');
  }

  // Salva dados na sessão
  req.session.userId = user._id;
  req.session.username = user.username;

  res.redirect('/home');
});

// Logout
app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/login');
  });
});

// Redireciona raiz pra login
app.get('/', (req, res) => {
  res.redirect('/login');
});

// Start servidor
app.listen(3000, () => {
  console.log('Servidor rodando em http://localhost:3000');
});
